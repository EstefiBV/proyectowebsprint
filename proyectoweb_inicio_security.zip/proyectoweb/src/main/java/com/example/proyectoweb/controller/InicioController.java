
package com.example.proyectoweb.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class InicioController {

    @GetMapping({"/", "/login"})
    public String mostrarInicio(Model model) {

        model.addAttribute(
                "titulo", "Sistema de Gestión de Productos");

        model.addAttribute(
                "curso", "Programación Avanzada");

        return "login";
    }

    @GetMapping("/acceso-denegado")
    public String accesoDenegado() {
        return "acceso-denegado";
    }
}
